import { TodoSearchPipe } from './todo-search.pipe';

describe('TodoSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new TodoSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
