import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-width-card-tab',
  templateUrl: './full-width-card-tab.component.html',
  styleUrls: ['./full-width-card-tab.component.scss']
})
export class FullWidthCardTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
